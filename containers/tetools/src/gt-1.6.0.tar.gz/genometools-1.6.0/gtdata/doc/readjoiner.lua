print ([[

Please consult the Readjoiner manual for more information.

Tools:

- *prefilter*    prepare the readset for Readjoiner
- *overlap*      calculate suffix-prefix matches
- *assembly*     construct string graph and output contigs]])
