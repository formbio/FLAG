    function mapping(sequence_region)
      return "hs_ref_"..sequence_region..".fa.gz"
    end
