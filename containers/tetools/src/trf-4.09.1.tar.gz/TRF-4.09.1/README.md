Please see https://tandem.bu.edu/trf/trf.html for more information.

The source code for this program is available at https://github.com/Benson-Genomics-Lab/TRF.

